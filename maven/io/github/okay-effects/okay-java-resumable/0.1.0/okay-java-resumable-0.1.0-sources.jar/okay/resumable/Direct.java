package okay.resumable;

import java.util.function.Predicate;
import okay.rows.Cell;
import okay.rows.Comp;
import okay.effect.Eff;
import okay.rows.Effects;
import okay.rows.Here;
import okay.rows.Once;
import okay.effect.Op;
import okay.effect.Pure;
import okay.effect.Sensitive;

/** DIRECT STYLE: a plain Java method performs operations and gets their answers as values; the effects it uses are
 * its {@code throws}. {@link #row}{@code (..).of} makes it an {@code okay.rows} program, whose row is those
 * effects, for the row's handlers to answer:
 *
 * <pre>{@code
 * static Receipt checkout(String user) throws Cart, Payments {
 *   int total = Direct.perform(new Cart.Total());
 *   String id = Direct.perform(new Payments.Charge(user, total));
 *   return new Receipt(id, total);
 * }
 *
 * Comp<Receipt, Eff<Cart, Eff<Payments, Pure>>> p = Direct.row(Cart.class, Payments.class).of(() -> checkout("ann"));
 * }</pre>
 *
 * A method that performs, or calls a method that may, must be transformed at build time (the module's plugin) or at
 * load time ({@code java -jar} of a jar whose manifest names the module's agent): its frames are then saved as data
 * when it suspends, and re-entered when the rest of the program is resumed — once, many times, or never. */
public final class Direct {
  private Direct() {}

  /** the operation asked, its answer returned. Its effect {@code E} is thrown for javac only: a transformed caller
   * does not call this method but its own path, which suspends. Called here, the caller was not transformed: the
   * operation is answered if its handler answers in place, and refused if the handler takes the rest. */
  public static <E extends Suspend, X, O extends Op<E, X, ? super O>> X perform(O op) throws E {
    return here(op);
  }

  /** a sensitive operation asked: its effect, at the first place of the program's row, is answered only under its
   * audit ({@link #sensitive}). As {@link #perform(Op)}, thrown for javac only */
  public static <E extends SensitiveSuspend, X, O extends Sensitive.Op<E, X, ? super O>> X perform(O op) throws E {
    Object answer = Driver.performSensitive(op);
    if (answer instanceof Capture) throw untransformed(op, 2);
    @SuppressWarnings("unchecked") // the answer of the operation, of the type the operation names
    X x = (X) answer;
    return x;
  }

  /** an operation of an effect written as a GADT ({@link Performed}) asked, its answer returned: of the type its
   * record names, {@code long price = Direct.perform(new Prices.Price(item))}. Its effect's name is thrown for
   * javac only, as {@link #perform(Op)}'s */
  public static <T, F, X extends Suspend & Marks<F>> T perform(Performed<T, F, X> op) throws X {
    return here(op);
  }

  /** an operation performed by a method that was NOT transformed: answered all the same where its handler answers
   * it in place — a handler in place, a clause that only resumes: nothing of the method has to be saved, so
   * nothing had to be transformed. Refused where the handler takes the rest of the program, or no program runs */
  @SuppressWarnings("unchecked") // the answer of the operation, of the type the operation names
  private static <T> T here(Op<?, ?, ?> op) {
    Object answer = Driver.perform(op);
    if (answer instanceof Capture) throw untransformed(op, 3);
    return (T) answer;
  }

  private static IllegalStateException untransformed(Object op) {
    return untransformed(op, 3);
  }

  private static IllegalStateException untransformed(Object op, int frames) {
    StackWalker.StackFrame caller = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE)
        .walk(s -> s.skip(frames).findFirst()).orElseThrow();
    String method = caller.getClassName() + "." + caller.getMethodName() + " (line " + caller.getLineNumber() + ")";
    String why = caller.getDeclaringClass().isAnnotationPresent(Transformed.class)
        ? "its class was transformed but this method was not (a constructor, a static initializer or a synchronized"
            + " method cannot suspend)"
        : "its class was not transformed: build it with the okay-java-resumable plugin (Gradle:"
            + " id(\"io.github.okay-effects.resumable\"); Maven: okay-java-resumable-maven-plugin), or run a jar with"
            + " java -jar, whose manifest's Launcher-Agent-Class transforms it as it is loaded. An IDE that compiles"
            + " by itself does not run the plugin: delegate the build and the tests to Gradle or Maven. (Without the"
            + " transformation a method performs only what a handler answers in place; this operation's handler"
            + " takes the rest of the program, or no program runs here)";
    return new IllegalStateException("okay.resumable: " + method + " performed " + op + ", but " + why
        + " — the rest of the program could not be resumed.");
  }

  /** how operations whose handler is general and declared {@code Once} are run here: on the JVM's continuations, or
   * — and why — on saved frames */
  public static String continuations() {
    return Loom.AVAILABLE ? "the JVM's continuations" : "saved frames: " + Loom.WHY_NOT;
  }

  // ---- a body of a row that is a SET (okay.rows.Sets): its effects in its type, no class for an effect

  /** A BODY IN PLAIN JAVA WHOSE ROW IS A SET: {@code static <R extends Ids & Clock> Comp<String, R> stamp() {
   * return Direct.body(d -> { String ref = d.perform(new Ids.Ref("B")); long now = d.perform(new Clock.Now());
   * return ref + "@" + now; }); }} — answers in locals, {@code for} and {@code if} as they are. {@code d} asks the
   * operations of the effects the row has, and javac refuses any other; nothing is declared for an effect, and no
   * {@code throws} names it. It runs with the plugin or without, the same way: an operation its handler answers in
   * place is answered on the body's own stack; where a handler takes the rest, the body waits on a stack of its
   * own and goes on ONCE — a handler that resumes that rest twice is refused when it does */
  public static <A, R> Comp<A, R> body(Asking<A, R> body) {
    Asks<R> d = new Asks<>();
    return Driver.program(Driver.BY_CLASS, () -> body.run(d), true);
  }

  /** a body of a set. It declares no exception: an effect written as a class (a {@code Suspend}, its name in a
   * {@code throws}) is of a row of places, and javac refuses a method of one called here; a checked exception of
   * the body's own is the body's to catch, or an effect ({@code Throws}) */
  @FunctionalInterface
  public interface Asking<A, R> {
    A run(Asks<R> d);
  }

  /** what a body of a set asks with: valid in its body, while it runs. A method the body calls takes it as a
   * parameter: {@code static <R extends Ids> String fresh(Asks<R> d) { return d.perform(new Ids.Ref("B")); }} */
  public static final class Asks<R> {
    Asks() {}

    /** the operation asked, its answer returned: its effect must be one the row has */
    @SuppressWarnings("unchecked") // the answer of the operation, of the type the operation names
    public <T> T perform(Op<? super R, T, ?> op) {
      Object answer = Driver.perform(op);
      if (answer instanceof Capture) throw new IllegalStateException("okay.resumable: " + op + " was asked through "
          + "a Direct.body's `d` where its body does not run — after it ended, on another thread, or kept in a "
          + "field: `d` is valid in its own body only, while it runs");
      return (T) answer;
    }

    /** a program of the row — a chain, a block — run as a part of the body, its value returned */
    public <A> A embed(Comp<A, ? super R> sub) {
      return Driver.embed(Driver.BY_CLASS, sub);
    }
  }

  @FunctionalInterface
  public interface Body1<A, E1 extends Exception> {
    A run() throws E1;
  }

  @FunctionalInterface
  public interface Body2<A, E1 extends Exception, E2 extends Exception> {
    A run() throws E1, E2;
  }

  @FunctionalInterface
  public interface Body3<A, E1 extends Exception, E2 extends Exception, E3 extends Exception> {
    A run() throws E1, E2, E3;
  }

  @FunctionalInterface
  public interface Body4<A, E1 extends Exception, E2 extends Exception, E3 extends Exception,
      E4 extends Exception> {
    A run() throws E1, E2, E3, E4;
  }

  /** THE ROW of a direct-style program, named once by its effects' classes, in the order of their handlers: an
   * operation goes to the place of its effect. Its {@code of} then takes a body that throws no effect outside it.
   * In two steps because javac would not infer the row in one: every effect a lambda throws becomes a lower bound
   * of every type variable of the interface's {@code throws}, so no single class fits them all. */
  public static <E1 extends Suspend> Row1<E1> row(Class<E1> e1) {
    return new Row1<>(plain(e1));
  }

  public static <E1 extends Suspend, E2 extends Suspend> Row2<E1, E2> row(Class<E1> e1, Class<E2> e2) {
    return new Row2<>(plain(e1, e2));
  }

  public static <E1 extends Suspend, E2 extends Suspend, E3 extends Suspend> Row3<E1, E2, E3> row(
      Class<E1> e1, Class<E2> e2, Class<E3> e3) {
    return new Row3<>(plain(e1, e2, e3));
  }

  public static <E1 extends Suspend, E2 extends Suspend, E3 extends Suspend, E4 extends Suspend>
      Row4<E1, E2, E3, E4> row(Class<E1> e1, Class<E2> e2, Class<E3> e3, Class<E4> e4) {
    return new Row4<>(plain(e1, e2, e3, e4));
  }

  public static final class Row1<E1 extends Suspend> {
    private final Class<?>[] row;

    private Row1(Class<?>[] row) { this.row = row; }

    /** the body as a program of the row: run when the program is */
    public <A> Comp<A, Eff<E1, Pure>> of(Body1<A, E1> body) {
      return Driver.program(row, body::run, body);
    }

    /** A SUB-PROGRAM OF THIS ROW, ITS HANDLERS INSIDE IT, run as a part of the program that calls this — no nested
     * run: its operations that leave it go to the program's handlers, and its value is returned. A handler installed
     * around a part of a body: {@code Direct.row(Log.class).embed(Counter.run(0, Direct.row(Counter.class, Log.class)
     * .of(() -> ..)))}. The program's row has these effects, in this order, and may have more */
    public <A> A embed(Comp<A, ? super Eff<E1, Pure>> sub) throws E1 {
      return Driver.embed(row, sub);
    }

    /** a handler written in direct style, its clauses performing this row's effects, outside the handler */
    public <F, A, B, R> okay.rows.Handler<F, A, B, Eff<E1, R>> handler(Handler1<F, A, B, E1> h) {
      return adapt(row, h, h::ret, h::on, h::mine);
    }
  }

  public static final class Row2<E1 extends Suspend, E2 extends Suspend> {
    private final Class<?>[] row;

    private Row2(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Eff<E1, Eff<E2, Pure>>> of(Body2<A, E1, E2> body) {
      return Driver.program(row, body::run, body);
    }

    public <A> A embed(Comp<A, ? super Eff<E1, Eff<E2, Pure>>> sub) throws E1, E2 {
      return Driver.embed(row, sub);
    }

    public <F, A, B, R> okay.rows.Handler<F, A, B, Eff<E1, Eff<E2, R>>> handler(Handler2<F, A, B, E1, E2> h) {
      return adapt(row, h, h::ret, h::on, h::mine);
    }
  }

  public static final class Row3<E1 extends Suspend, E2 extends Suspend, E3 extends Suspend> {
    private final Class<?>[] row;

    private Row3(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Eff<E1, Eff<E2, Eff<E3, Pure>>>> of(Body3<A, E1, E2, E3> body) {
      return Driver.program(row, body::run, body);
    }

    public <A> A embed(Comp<A, ? super Eff<E1, Eff<E2, Eff<E3, Pure>>>> sub) throws E1, E2, E3 {
      return Driver.embed(row, sub);
    }

    public <F, A, B, R> okay.rows.Handler<F, A, B, Eff<E1, Eff<E2, Eff<E3, R>>>> handler(
        Handler3<F, A, B, E1, E2, E3> h) {
      return adapt(row, h, h::ret, h::on, h::mine);
    }
  }

  public static final class Row4<E1 extends Suspend, E2 extends Suspend, E3 extends Suspend, E4 extends Suspend> {
    private final Class<?>[] row;

    private Row4(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Eff<E1, Eff<E2, Eff<E3, Eff<E4, Pure>>>>> of(Body4<A, E1, E2, E3, E4> body) {
      return Driver.program(row, body::run, body);
    }

    public <A> A embed(Comp<A, ? super Eff<E1, Eff<E2, Eff<E3, Eff<E4, Pure>>>>> sub) throws E1, E2, E3, E4 {
      return Driver.embed(row, sub);
    }

    public <F, A, B, R> okay.rows.Handler<F, A, B, Eff<E1, Eff<E2, Eff<E3, Eff<E4, R>>>>> handler(
        Handler4<F, A, B, E1, E2, E3, E4> h) {
      return adapt(row, h, h::ret, h::on, h::mine);
    }
  }

  /** THE ROW of a direct-style program whose effects are written as GADTs, named by their names in a
   * {@code throws} ({@link Marks}), in the order of their handlers: the program's row is of the effects they stand
   * for — {@code Direct.effects(Prices.Fx.class, Ask.Fx.class).of(() -> shop(cart))} is a
   * {@code Comp<A, Eff<Prices<?>, Eff<Ask<?>, Pure>>>}. */
  public static <F1, X1 extends Suspend & Marks<F1>> Effects1<F1, X1> effects(Class<X1> x1) {
    return new Effects1<>(plain(x1));
  }

  public static <F1, X1 extends Suspend & Marks<F1>, F2, X2 extends Suspend & Marks<F2>> Effects2<F1, X1, F2, X2>
      effects(Class<X1> x1, Class<X2> x2) {
    return new Effects2<>(plain(x1, x2));
  }

  public static <F1, X1 extends Suspend & Marks<F1>, F2, X2 extends Suspend & Marks<F2>,
      F3, X3 extends Suspend & Marks<F3>> Effects3<F1, X1, F2, X2, F3, X3> effects(
      Class<X1> x1, Class<X2> x2, Class<X3> x3) {
    return new Effects3<>(plain(x1, x2, x3));
  }

  public static final class Effects1<F1, X1 extends Suspend & Marks<F1>> {
    private final Class<?>[] row;

    private Effects1(Class<?>[] row) { this.row = row; }

    /** the body as a program of the row: run when the program is */
    public <A> Comp<A, Eff<F1, Pure>> of(Body1<A, X1> body) {
      return Driver.program(row, body::run, body);
    }

    /** a sub-program of this row, its handlers inside it, run as a part of the program that calls this
     * ({@link Row1#embed}) */
    public <A> A embed(Comp<A, ? super Eff<F1, Pure>> sub) throws X1 {
      return Driver.embed(row, sub);
    }
  }

  public static final class Effects2<F1, X1 extends Suspend & Marks<F1>, F2, X2 extends Suspend & Marks<F2>> {
    private final Class<?>[] row;

    private Effects2(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Eff<F1, Eff<F2, Pure>>> of(Body2<A, X1, X2> body) {
      return Driver.program(row, body::run, body);
    }

    public <A> A embed(Comp<A, ? super Eff<F1, Eff<F2, Pure>>> sub) throws X1, X2 {
      return Driver.embed(row, sub);
    }
  }

  public static final class Effects3<F1, X1 extends Suspend & Marks<F1>, F2, X2 extends Suspend & Marks<F2>,
      F3, X3 extends Suspend & Marks<F3>> {
    private final Class<?>[] row;

    private Effects3(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Eff<F1, Eff<F2, Eff<F3, Pure>>>> of(Body3<A, X1, X2, X3> body) {
      return Driver.program(row, body::run, body);
    }

    public <A> A embed(Comp<A, ? super Eff<F1, Eff<F2, Eff<F3, Pure>>>> sub) throws X1, X2, X3 {
      return Driver.embed(row, sub);
    }
  }

  /** the classes of a row's plain places. javac keeps a sensitive effect out of them; a raw {@code Class} would not,
   * so it is refused here too */
  private static Class<?>[] plain(Class<?>... effects) {
    for (Class<?> e : effects)
      if (!Suspend.class.isAssignableFrom(e)) throw new IllegalArgumentException("okay.resumable: " + e.getName()
          + " is not a plain effect (a subclass of Suspend); a sensitive one is placed by Direct.sensitive");
    return effects;
  }

  /** the row's classes: the sensitive effect first, then the plain ones */
  private static Class<?>[] places(SensitivePlace<?> s, Class<?>... effects) {
    Class<?>[] all = new Class<?>[effects.length + 1];
    all[0] = s.effect;
    System.arraycopy(plain(effects), 0, all, 1, effects.length);
    return all;
  }

  /** A SENSITIVE EFFECT's place, first in a row: {@code Direct.row(Direct.sensitive(Pay.class), Log.class)}. The
   * program's row then begins with {@code Sensitive<Pay, ..>}, which only {@code Audit.audit} takes */
  public static <S extends SensitiveSuspend> SensitivePlace<S> sensitive(Class<S> effect) {
    if (!SensitiveSuspend.class.isAssignableFrom(effect)) throw new IllegalArgumentException("okay.resumable: "
        + effect.getName() + " is not a sensitive effect (a subclass of SensitiveSuspend)");
    return new SensitivePlace<>(effect);
  }

  public static final class SensitivePlace<S extends SensitiveSuspend> {
    private final Class<S> effect;

    private SensitivePlace(Class<S> effect) { this.effect = effect; }
  }

  public static <S extends SensitiveSuspend> SensitiveRow1<S> row(SensitivePlace<S> s) {
    return new SensitiveRow1<>(places(s));
  }

  public static <S extends SensitiveSuspend, E1 extends Suspend> SensitiveRow2<S, E1> row(SensitivePlace<S> s,
      Class<E1> e1) {
    return new SensitiveRow2<>(places(s, e1));
  }

  public static <S extends SensitiveSuspend, E1 extends Suspend, E2 extends Suspend> SensitiveRow3<S, E1, E2> row(
      SensitivePlace<S> s, Class<E1> e1, Class<E2> e2) {
    return new SensitiveRow3<>(places(s, e1, e2));
  }

  public static <S extends SensitiveSuspend, E1 extends Suspend, E2 extends Suspend, E3 extends Suspend>
      SensitiveRow4<S, E1, E2, E3> row(SensitivePlace<S> s, Class<E1> e1, Class<E2> e2, Class<E3> e3) {
    return new SensitiveRow4<>(places(s, e1, e2, e3));
  }

  /** a row whose first place is sensitive: its programs are run, and that effect handled, under its audit only.
   * Open after its effects, unlike a plain row: an audit's interceptor asks effects of its own outside the program,
   * a trail, a failure — the program fits a row that has them further out */
  public static final class SensitiveRow1<S extends SensitiveSuspend> {
    private final Class<?>[] row;

    private SensitiveRow1(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Sensitive<S, ?>> of(Body1<A, S> body) {
      return Driver.program(row, body::run, body);
    }
  }

  public static final class SensitiveRow2<S extends SensitiveSuspend, E1 extends Suspend> {
    private final Class<?>[] row;

    private SensitiveRow2(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Sensitive<S, ? extends Eff<E1, ?>>> of(Body2<A, S, E1> body) {
      return Driver.program(row, body::run, body);
    }
  }

  public static final class SensitiveRow3<S extends SensitiveSuspend, E1 extends Suspend, E2 extends Suspend> {
    private final Class<?>[] row;

    private SensitiveRow3(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Sensitive<S, ? extends Eff<E1, ? extends Eff<E2, ?>>>> of(Body3<A, S, E1, E2> body) {
      return Driver.program(row, body::run, body);
    }
  }

  public static final class SensitiveRow4<S extends SensitiveSuspend, E1 extends Suspend, E2 extends Suspend,
      E3 extends Suspend> {
    private final Class<?>[] row;

    private SensitiveRow4(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, Sensitive<S, ? extends Eff<E1, ? extends Eff<E2, ? extends Eff<E3, ?>>>>> of(
        Body4<A, S, E1, E2, E3> body) {
      return Driver.program(row, body::run, body);
    }
  }

  // ---- sensitive places anywhere in a row, any number of them: Direct.row(Log.class, Direct.sensitive(Pay.class)),
  // Direct.row(Direct.sensitive(Pay.class), Log.class, Direct.sensitive(Mail.class)). Each sensitive place is
  // Sensitive<S, ..> in the row's type — taken by its audit only, once the places before it are handled — and the
  // row is open after it, for its interceptor's effects

  /** the row's classes, of plain places (a Class, checked) and sensitive ones */
  private static Class<?>[] places(Object... places) {
    Class<?>[] all = new Class<?>[places.length];
    for (int i = 0; i < places.length; i++)
      all[i] = places[i] instanceof SensitivePlace<?> s ? s.effect : plain((Class<?>) places[i])[0];
    return all;
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend>
      Places2<E1, E2, Eff<E1, Sensitive<E2, ?>>> row(
      Class<E1> e1, SensitivePlace<E2> e2) {
    return new Places2<>(places(e1, e2));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend>
      Places2<E1, E2, Sensitive<E1, ? extends Sensitive<E2, ?>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2) {
    return new Places2<>(places(e1, e2));
  }

  /** a row of 2 places, one or more of them sensitive, its type {@code R} */
  public static final class Places2<E1 extends Exception, E2 extends Exception,
      R> {
    private final Class<?>[] row;

    private Places2(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, R> of(Body2<A, E1, E2> body) {
      return Driver.program(row, body::run, body);
    }
  }

  public static <E1 extends Suspend, E2 extends Suspend,
      E3 extends SensitiveSuspend>
      Places3<E1, E2, E3, Eff<E1, Eff<E2, Sensitive<E3, ?>>>> row(
      Class<E1> e1, Class<E2> e2, SensitivePlace<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends Suspend>
      Places3<E1, E2, E3, Eff<E1, Sensitive<E2, ? extends Eff<E3, ?>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, Class<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend>
      Places3<E1, E2, E3, Eff<E1, Sensitive<E2, ? extends Sensitive<E3, ?>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  public static <E1 extends SensitiveSuspend, E2 extends Suspend,
      E3 extends SensitiveSuspend>
      Places3<E1, E2, E3, Sensitive<E1, ? extends Eff<E2, Sensitive<E3, ?>>>> row(
      SensitivePlace<E1> e1, Class<E2> e2, SensitivePlace<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends Suspend>
      Places3<E1, E2, E3, Sensitive<E1, ? extends Sensitive<E2, ? extends Eff<E3, ?>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, Class<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend>
      Places3<E1, E2, E3, Sensitive<E1, ? extends Sensitive<E2, ? extends Sensitive<E3, ?>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3) {
    return new Places3<>(places(e1, e2, e3));
  }

  /** a row of 3 places, one or more of them sensitive, its type {@code R} */
  public static final class Places3<E1 extends Exception, E2 extends Exception, E3 extends Exception,
      R> {
    private final Class<?>[] row;

    private Places3(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, R> of(Body3<A, E1, E2, E3> body) {
      return Driver.program(row, body::run, body);
    }
  }

  public static <E1 extends Suspend, E2 extends Suspend,
      E3 extends Suspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Eff<E1, Eff<E2, Eff<E3, Sensitive<E4, ?>>>>> row(
      Class<E1> e1, Class<E2> e2, Class<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends Suspend,
      E3 extends SensitiveSuspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4, Eff<E1, Eff<E2, Sensitive<E3, ? extends Eff<E4, ?>>>>> row(
      Class<E1> e1, Class<E2> e2, SensitivePlace<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends Suspend,
      E3 extends SensitiveSuspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Eff<E1, Eff<E2, Sensitive<E3, ? extends Sensitive<E4, ?>>>>> row(
      Class<E1> e1, Class<E2> e2, SensitivePlace<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends Suspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4, Eff<E1, Sensitive<E2, ? extends Eff<E3, Eff<E4, ?>>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, Class<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends Suspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Eff<E1, Sensitive<E2, ? extends Eff<E3, Sensitive<E4, ?>>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, Class<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4, Eff<E1, Sensitive<E2, ? extends Sensitive<E3, ? extends Eff<E4, ?>>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends Suspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Eff<E1, Sensitive<E2, ? extends Sensitive<E3, ? extends Sensitive<E4, ?>>>>> row(
      Class<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends Suspend,
      E3 extends Suspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Sensitive<E1, ? extends Eff<E2, Eff<E3, Sensitive<E4, ?>>>>> row(
      SensitivePlace<E1> e1, Class<E2> e2, Class<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends Suspend,
      E3 extends SensitiveSuspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4, Sensitive<E1, ? extends Eff<E2, Sensitive<E3, ? extends Eff<E4, ?>>>>> row(
      SensitivePlace<E1> e1, Class<E2> e2, SensitivePlace<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends Suspend,
      E3 extends SensitiveSuspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Sensitive<E1, ? extends Eff<E2, Sensitive<E3, ? extends Sensitive<E4, ?>>>>> row(
      SensitivePlace<E1> e1, Class<E2> e2, SensitivePlace<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends Suspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4, Sensitive<E1, ? extends Sensitive<E2, ? extends Eff<E3, Eff<E4, ?>>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, Class<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends Suspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4, Sensitive<E1, ? extends Sensitive<E2, ? extends Eff<E3, Sensitive<E4, ?>>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, Class<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend, E4 extends Suspend>
      Places4<E1, E2, E3, E4,
          Sensitive<E1, ? extends Sensitive<E2, ? extends Sensitive<E3, ? extends Eff<E4, ?>>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3, Class<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  public static <E1 extends SensitiveSuspend, E2 extends SensitiveSuspend,
      E3 extends SensitiveSuspend, E4 extends SensitiveSuspend>
      Places4<E1, E2, E3, E4,
          Sensitive<E1, ? extends Sensitive<E2, ? extends Sensitive<E3, ? extends Sensitive<E4, ?>>>>> row(
      SensitivePlace<E1> e1, SensitivePlace<E2> e2, SensitivePlace<E3> e3, SensitivePlace<E4> e4) {
    return new Places4<>(places(e1, e2, e3, e4));
  }

  /** a row of 4 places, one or more of them sensitive, its type {@code R} */
  public static final class Places4<E1 extends Exception, E2 extends Exception, E3 extends Exception,
      E4 extends Exception,
      R> {
    private final Class<?>[] row;

    private Places4(Class<?>[] row) { this.row = row; }

    public <A> Comp<A, R> of(Body4<A, E1, E2, E3, E4> body) {
      return Driver.program(row, body::run, body);
    }
  }

  // ---- handlers in direct style

  /** What a clause that resumes the rest declares, beside the effects it performs: {@code k.resume} suspends the
   * clause while the rest of the handled program runs, and javac then keeps it out of code that cannot suspend (a
   * JDK lambda). No operation is of it */
  public static final class Resumes extends Suspend {
    private Resumes() {}
  }

  /** THE REST of a handled program, given to a direct-style clause: {@code k.resume(op, x)} runs it with the answer
   * {@code x} to the handler's result, and returns that — once, many times, or never ({@code k.unwind()}: its
   * finalizers run). Deep, as okay.rows' {@code K}: the rest runs under the handler again. Called by the handler's
   * own clauses only; nothing is replayed — the clause's frames are saved while the rest runs, and resumed with its
   * result. {@code return k.resume(..)} adds nothing for each operation: in tail position the clause's program is the
   * resumption itself */
  public static final class K<B> extends Driver.Prog {
    private final okay.rows.K<B, ?> k;
    /** the operation asked, and the handler whose clause was given this */
    final Object asked;
    final Adapter<?, ?, B, ?> handler;

    K(okay.rows.K<B, ?> k, Class<?>[] row, Object asked, Adapter<?, ?, B, ?> handler) {
      super(row);
      this.k = k;
      this.asked = asked;
      this.handler = handler;
    }

    /** the rest resumed with the answer to {@code op}, the operation asked, and run to the handler's result */
    public <X> B resume(Op<?, X, ?> op, X answer) throws Resumes {
      Driver.valid(this);
      return Driver.await(k.resume(op, answer));
    }

    /** the same, of a sensitive operation: by a handler under its audit ({@code Audit.handle}) */
    public <X> B resume(Sensitive.Op<?, X, ?> op, X answer) throws Resumes {
      Driver.valid(this);
      return Driver.await(k.resume(op, answer));
    }

    /** the rest left: its finalizers run, the innermost first; nothing else of it */
    public void unwind() throws Resumes {
      Driver.valid(this);
      Driver.await(k.unwind());
    }
  }

  /** A GENERAL HANDLER IN DIRECT STYLE of the effect {@code F}, in a program of an {@code A}: a {@code B}. Its
   * clauses are plain methods, transformed as a body is: {@code on} is given the operation and the rest, and returns
   * the handler's result. Made an okay.rows {@code Handler} by {@link Direct#handler}, so it is installed, and
   * composes, as any: {@code handle}, {@code intercept}, {@code Audit.handle}. Declaring {@code okay.rows.Once}
   * declares it of that handler */
  public interface Handler0<F, A, B> {
    B ret(A a);

    B on(F op, K<B> k) throws Resumes;

    /** for an interceptor: of the operations of its class, those it takes */
    default boolean mine(F op) { return true; }
  }

  /** the same, its clauses performing {@code E1}, the effect next outside it: {@code Direct.row(E1.class)
   * .handler(h)}. javac refuses a clause that performs any other */
  public interface Handler1<F, A, B, E1 extends Suspend> {
    B ret(A a) throws E1;

    B on(F op, K<B> k) throws E1, Resumes;

    default boolean mine(F op) { return true; }
  }

  public interface Handler2<F, A, B, E1 extends Suspend, E2 extends Suspend> {
    B ret(A a) throws E1, E2;

    B on(F op, K<B> k) throws E1, E2, Resumes;

    default boolean mine(F op) { return true; }
  }

  public interface Handler3<F, A, B, E1 extends Suspend, E2 extends Suspend, E3 extends Suspend> {
    B ret(A a) throws E1, E2, E3;

    B on(F op, K<B> k) throws E1, E2, E3, Resumes;

    default boolean mine(F op) { return true; }
  }

  public interface Handler4<F, A, B, E1 extends Suspend, E2 extends Suspend, E3 extends Suspend,
      E4 extends Suspend> {
    B ret(A a) throws E1, E2, E3, E4;

    B on(F op, K<B> k) throws E1, E2, E3, E4, Resumes;

    default boolean mine(F op) { return true; }
  }

  /** a direct-style handler whose clauses perform nothing outside it, as an okay.rows {@code Handler} */
  public static <F, A, B, R> okay.rows.Handler<F, A, B, R> handler(Handler0<F, A, B> h) {
    return adapt(new Class<?>[0], h, h::ret, h::on, h::mine);
  }

  /** A HANDLER IN PLACE in direct style: each operation answered at once from a state, per path — and so on the
   * body's own stack, nothing suspended. As okay.rows' {@code InPlace}, its result a value */
  public interface InPlace<F, S, A, B> {
    B ret(S state, A a);

    Cell.Answered answer(Cell<S> state, F op);

    default boolean mine(F op) { return true; }
  }

  public static <F, S, A, B, R> okay.rows.InPlace<F, S, A, B, R> inPlace(InPlace<F, S, A, B> h) {
    return new okay.rows.InPlace<>() {
      public Comp<B, R> ret(S state, A a) { return Effects.pure(h.ret(state, a)); }
      public Cell.Answered answer(Cell<S> state, F op) { return h.answer(state, op); }
      public boolean mine(F op) { return h.mine(op); }
    };
  }

  /** a clause as the adapter calls it */
  interface Ret<A, B> {
    B apply(A a) throws Exception;
  }

  interface On<F, B> {
    B apply(F op, K<B> k) throws Exception;
  }

  /** the okay.rows handler of a direct-style one: each clause run as a program of the row outside, {@code row} its
   * effects' classes — one array for each handler, by which its {@code k} knows its clauses */
  private static <F, A, B, R> okay.rows.Handler<F, A, B, R> adapt(Class<?>[] row, Object h, Ret<A, B> ret,
      On<F, B> on, Predicate<F> mine) {
    return h instanceof Once ? new OnceAdapter<>(row, ret, on, mine) : new Adapter<>(row, ret, on, mine);
  }

  /** asked from the body's stack ({@link Here.Eager}): its clause made there, and answered at once if it resumes in
   * tail position */
  static class Adapter<F, A, B, R> implements okay.rows.Handler<F, A, B, R>, Here.Eager {
    private final Class<?>[] row;
    private final Ret<A, B> ret;
    private final On<F, B> on;
    private final Predicate<F> mine;
    /** the program of each ret: a clause given no k */
    private final Driver.Prog rets;

    Adapter(Class<?>[] row, Ret<A, B> ret, On<F, B> on, Predicate<F> mine) {
      this.row = row;
      this.ret = ret;
      this.on = on;
      this.mine = mine;
      this.rets = new Driver.Prog(row);
    }

    /** how often its clauses resumed the rest in tail position, and not: counted from any thread, unsynchronized —
     * a count lost only changes which way an operation is asked, never its answer */
    private int tails;
    private int nonTails;

    void resumed(boolean tail) {
      if (tail) tails++;
      else nonTails++;
    }

    /** asked from the body's stack while its clauses resume in tail position as often as not: a handler that
     * resumes otherwise (a choice, a log after the rest) gains nothing there, its frames saved anyway */
    @Override
    public boolean eager() {
      return nonTails <= tails;
    }

    public Comp<B, R> ret(A a) {
      return Driver.clause(rets, () -> ret.apply(a), Driver.RET);
    }

    public Comp<B, R> on(F op, okay.rows.K<B, R> k) {
      K<B> rest = new K<>(k, row, op, this);
      return Driver.clause(rest, () -> on.apply(op, rest), Driver.ON);
    }

    public boolean mine(F op) {
      return mine.test(op);
    }
  }

  private static final class OnceAdapter<F, A, B, R> extends Adapter<F, A, B, R> implements Once {
    OnceAdapter(Class<?>[] row, Ret<A, B> ret, On<F, B> on, Predicate<F> mine) {
      super(row, ret, on, mine);
    }
  }
}
